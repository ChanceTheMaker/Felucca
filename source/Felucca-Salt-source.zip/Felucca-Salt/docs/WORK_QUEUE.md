# Felucca Salt work queue

Deferred requests for a future round. Listing an item here does not add it to
the current implementation or publish.

## Website

- [x] **Make the header logo link to the homepage.** Implemented after
  the owner brought it into scope on 2026-10-05. The “Felucca [Salt]” logo on both
  pages links to the installer homepage, with its size/styling preserved and
  visible keyboard focus. The owner authorized merging into the fork's main;
  live deployment is separate.
